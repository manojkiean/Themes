<?php
$mts_options = get_option(MTS_THEME_NAME);
global $j; ?>

<article class="latestPost excerpt">
	<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left">
		<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('newstoday-hero',array('title' => '')); echo '</div>'; ?>
		<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
		<?php if ($mts_options['mts_home_category'] == '1') { ?>
			<?php $category = get_the_category();  if(!empty($category)){ ?>
				<div class="thecategory"<?php if (mts_get_category_color()) { echo ' style="background: '.mts_get_category_color().';"'; } ?>><?php echo $category[0]->cat_name; ?></div>
			<?php } ?>
		<?php } ?>
		<header>
			<h2 class="title front-view-title"><?php the_title(); ?></h2>
			<div class="read-story"><?php _e( '<i class="fa fa-arrow-circle-o-right"></i> Read Story', 'newstoday' ); ?></div>
			<?php mts_the_postinfo(); ?>
		</header>
	</a>
</article>