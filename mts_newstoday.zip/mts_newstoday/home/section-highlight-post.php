<?php 
$mts_options = get_option(MTS_THEME_NAME);
global $j; ?>

<article class="latestPost excerpt <?php echo 'post-' . $j; ?>">
	<?php if ( $j == 1 || $j == 2 ) { ?> 
		<?php if ($mts_options['mts_home_category'] == '1') {
			$category = get_the_category();  if(!empty($category)){ ?>
				<div class="thecategory"<?php if (mts_get_category_color()) { echo ' style="background: '.mts_get_category_color().';"'; } ?>><?php echo '<a href="'.get_category_link( $category[0]->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s", 'newstoday' ), $category[0]->name ) ) . '">'.$category[0]->cat_name.'</a>'; ?></div>
			<?php }
		} ?>
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left">
			<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('newstoday-highlights',array('title' => '')); echo '</div>'; ?>
			<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
			<header>
				<h2 class="title front-view-title"><?php the_title(); ?></h2>
			</header>
		</a>
		<?php mts_the_postinfo(); ?>
	<?php } ?>

	<?php if ( $j == 3 || $j == 4 ) { ?>
		<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left highlights-small">
			<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('newstoday-highlights-small',array('title' => '')); echo '</div>'; ?>
			<header>
				<h2 class="title front-view-title"><?php the_title(); ?></h2>
			</header>
		</a>
	<?php } ?>

	<?php if ( $j > 4 ) { ?>
		<header>
			<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php the_title(); ?></a></h2>
			<?php mts_the_postinfo(); ?>
		</header>
	<?php } ?>
</article>