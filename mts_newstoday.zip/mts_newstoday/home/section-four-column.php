<?php 
$mts_options = get_option(MTS_THEME_NAME);
global $j; ?>

<article class="latestPost excerpt <?php echo ( ($j % 4 == 0) ) ? 'last' : ''; ?>">
	<a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" class="post-image post-image-left">
		<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('newstoday-fourfeatured',array('title' => '')); echo '</div>'; ?>
		<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
		<?php if ($mts_options['mts_home_category'] == '1') { ?>
			<?php $category = get_the_category();  if(!empty($category)){ ?>
				<div class="thecategory"<?php if (mts_get_category_color()) { echo ' style="background: '.mts_get_category_color().';"'; } ?>><?php echo $category[0]->cat_name; ?></div>
			<?php } ?>
		<?php } ?>
	</a>
	<header>
		<h2 class="title front-view-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo mts_truncate( get_the_title(), 50 ); ?></a></h2>
		<?php mts_the_postinfo(); ?>
	</header>
</article>