<?php
// make sure to not include translations
$args['presets']['default'] = array(
	'title' => 'Default',
	'demo' => 'http://demo.mythemeshop.com/newstoday/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/default/thumb.jpg', // could use external url, to minimize theme zip size
	'menus' => array( 'primary-menu' => 'Primary', 'footer-menu' => 'Footer', 'mobile' => 'Mobile Menu' ), // menu location slug => Demo menu name
	'options' => array( 'show_on_front' => 'posts' ),
);

$args['presets']['dark'] = array(
	'title' => 'Dark',
	'demo' => 'http://demo.mythemeshop.com/newstoday-dark/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/dark/thumb.jpg', // could use external url, to minimize theme zip size
	'menus' => array( 'primary-menu' => 'Primary', 'footer-menu' => 'Footer', 'mobile' => 'Mobile Menu' ), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

$args['presets']['craft'] = array(
	'title' => 'Craft',
	'demo' => 'http://demo.mythemeshop.com/newstoday-craft/',
	'thumbnail' => get_template_directory_uri().'/options/demo-importer/demo-files/craft/thumb.jpg', // could use external url, to minimize theme zip size
	'menus' => array( 'primary-menu' => 'Primary', 'footer-menu' => 'Footer', 'mobile' => 'Mobile Menu' ), // menu location slug => Demo menu name
	//'options' => array( 'show_on_front' => 'page', 'page_on_front' => '4' ), // To set static front page
);

global $mts_presets;
$mts_presets = $args['presets'];
